from django.contrib import admin
from .models import Indexs

admin.site.register(Indexs)
